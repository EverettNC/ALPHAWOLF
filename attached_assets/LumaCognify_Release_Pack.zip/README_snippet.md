![LumaCognify Badge](badge/luma_badge.png)

> 🔹 **Powered by LumaCognify AI**  
> 🔓 Open Source | Morally Licensed  
> 💙 *"How can I help you love yourself more?"*

This project is licensed under the **LumaCognify Public Covenant License**.  
We protect freedom, dignity, and access. Always.
